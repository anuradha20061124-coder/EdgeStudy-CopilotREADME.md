# Sample Data

Place your own study PDFs here for local testing.

Do not commit private documents, passwords, API keys, personal records, or copyrighted material you do not have permission to redistribute.
