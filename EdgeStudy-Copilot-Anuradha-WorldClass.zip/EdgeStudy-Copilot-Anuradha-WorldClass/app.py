import os
import re
import time
from typing import List, Tuple, Optional

import fitz
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(
    page_title="EdgeStudy Copilot",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("📚 EdgeStudy Copilot")
st.caption("Private • Grounded • Edge-first learning assistant | Built by Anuradha")


def extract_pdf(data: bytes) -> List[Tuple[int, str]]:
    doc = fitz.open(stream=data, filetype="pdf")
    pages = []
    for i, page in enumerate(doc):
        text = page.get_text("text").strip()
        if text:
            pages.append((i + 1, text))
    return pages


def chunks(text: str, words: int = 180, overlap: int = 35) -> List[str]:
    tokens = text.split()
    step = max(1, words - overlap)
    output = []
    for start in range(0, len(tokens), step):
        chunk = " ".join(tokens[start:start + words]).strip()
        if len(chunk.split()) >= 30:
            output.append(chunk)
    return output


def build_index(data: List[str]):
    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=12000,
    )
    matrix = vectorizer.fit_transform(data)
    return vectorizer, matrix


def retrieve(query: str, data: List[str], vectorizer, matrix, k: int = 4):
    scores = cosine_similarity(vectorizer.transform([query]), matrix).ravel()
    ids = scores.argsort()[::-1][:k]
    return [(data[i], float(scores[i])) for i in ids if scores[i] > 0]


def extractive_answer(query: str, results) -> str:
    if not results:
        return "I could not find enough evidence in your uploaded material. Try asking about a concept that appears in the notes."

    query_words = set(re.findall(r"[a-zA-Z]{3,}", query.lower()))
    ranked = []
    for chunk, similarity in results:
        sentences = re.split(r"(?<=[.!?])\s+", chunk)
        for sentence in sentences:
            if len(sentence) < 35:
                continue
            words = set(re.findall(r"[a-zA-Z]{3,}", sentence.lower()))
            overlap = len(query_words & words)
            ranked.append((overlap + similarity, sentence.strip()))

    ranked.sort(reverse=True, key=lambda x: x[0])
    return " ".join(sentence for _, sentence in ranked[:4])


def local_ollama_answer(query: str, context: str) -> Optional[str]:
    try:
        import requests
        model = os.getenv("OLLAMA_MODEL", "qwen3:4b")
        prompt = f"""You are EdgeStudy Copilot, created by Anuradha.
Answer only from the supplied study context. If evidence is insufficient, say so.
Explain clearly for a student and do not invent facts.

Question:
{query}

Study context:
{context}
"""
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=60,
        )
        if response.ok:
            answer = response.json().get("response", "").strip()
            return answer or None
    except Exception:
        return None
    return None


with st.sidebar:
    st.header("⚙️ Runtime & Privacy")
    mode = st.radio(
        "Inference mode",
        ["Local only", "Local + optional local LLM"],
    )
    st.success("Core MVP works without a cloud API.")
    st.info(
        "For competition evidence, test the chosen model/runtime on the target Snapdragon-powered HP PC and record real measurements."
    )
    st.markdown("### Learning loop")
    st.markdown("**Explain → Practice → Revise → Re-test**")

uploaded = st.file_uploader("📄 Upload a study PDF", type=["pdf"])
notes = st.text_area("📝 Or paste study notes", height=170)

if uploaded or notes.strip():
    if uploaded:
        pages = extract_pdf(uploaded.getvalue())
        source_text = "\n".join(text for _, text in pages)
        st.caption(f"Loaded {len(pages)} text-bearing PDF page(s).")
    else:
        source_text = notes

    data = chunks(source_text)
    if not data:
        st.warning("Not enough text was found to build a local index.")
        st.stop()

    vectorizer, matrix = build_index(data)
    st.success(f"Indexed {len(data)} local study chunks.")

    query = st.text_input("🔎 Ask a question about your material")
    if query:
        start = time.perf_counter()
        results = retrieve(query, data, vectorizer, matrix)
        retrieval_ms = (time.perf_counter() - start) * 1000
        context = "\n\n".join(chunk for chunk, _ in results)

        answer = None
        if mode == "Local + optional local LLM":
            answer = local_ollama_answer(query, context)
        if not answer:
            answer = extractive_answer(query, results)

        st.subheader("💡 Answer")
        st.write(answer)
        st.caption(f"Local retrieval latency: {retrieval_ms:.1f} ms")

        with st.expander("🔍 Evidence used"):
            if not results:
                st.write("No matching evidence found.")
            for i, (chunk, score) in enumerate(results, 1):
                st.markdown(f"**Evidence {i} — similarity {score:.3f}**")
                st.write(chunk)

    st.divider()
    st.subheader("🎯 QuizForge")
    if st.button("Generate 5 practice prompts"):
        results = retrieve(
            "key concepts definitions important principles examples",
            data,
            vectorizer,
            matrix,
            k=5,
        )
        if not results:
            st.info("No strong evidence was found for practice generation.")
        for i, (chunk, _) in enumerate(results, 1):
            first = re.split(r"(?<=[.!?])\s+", chunk)[0]
            st.markdown(f"**Q{i}. Explain this idea in your own words:**")
            st.write(first)
            st.write("Your answer: __________________________________________")
else:
    st.info("Upload a PDF or paste notes to start your private study workspace.")
    st.markdown("### Demo flow")
    st.markdown("**Upload → Ask → Evidence → Practice → Revise → Re-test**")
