# 📚 EdgeStudy Copilot

### Private • Grounded • Edge-First AI Learning for Snapdragon-Powered HP PCs

**Built by Anuradha** | Snapdragon AI Lab Build & Present Challenge

> **EdgeStudy Copilot** turns a learner's own notes and PDFs into a focused study workspace. The MVP prioritizes local retrieval, evidence-grounded answers, practice generation, and a modular model layer designed for future Snapdragon/Qualcomm AI Hub optimization.

---

## 🌟 Why EdgeStudy Copilot?

Most study assistants treat every question like a generic chatbot request. EdgeStudy Copilot starts with **the learner's own material** and follows a learning loop:

**Explain → Practice → Detect Weakness → Revise → Re-test**

The product is designed around three principles:

- 🔒 **Privacy-first:** study material can remain on the device in the core MVP.
- 🎯 **Grounded:** answers are retrieved from the learner's supplied material instead of relying only on general model knowledge.
- ⚡ **Edge-ready:** the model/runtime layer is modular so a compact, quantized model can be optimized and deployed for the target Snapdragon PC after hardware validation.

---

## 🚀 MVP Features

| Feature | Current MVP |
|---|---|
| PDF study-material ingestion | ✅ |
| Local text extraction | ✅ |
| Local TF-IDF retrieval | ✅ |
| Evidence display | ✅ |
| Student-friendly answers | ✅ |
| Practice-question generation | ✅ |
| Optional local LLM via Ollama | ✅ |
| Retrieval latency measurement | ✅ |
| Cloud API required | ❌ |
| Qualcomm AI Hub hardware benchmark | ⏳ Target validation |

**Important:** no Qualcomm AI Hub integration, Snapdragon acceleration, or hardware benchmark is claimed until it is actually tested and documented on the target device.

---

## 🧠 System Architecture

```text
        ┌──────────────────────────────┐
        │ Learner PDFs / Study Notes   │
        └──────────────┬───────────────┘
                       ↓
              Local Text Extraction
                       ↓
                Chunking / Indexing
                       ↓
             Local Retrieval (TF-IDF)
                       ↓
              Relevant Evidence
                       ↓
          ┌────────────┴────────────┐
          │                         │
   Extractive Answer       Optional Local LLM
          │                    (Ollama)
          └────────────┬────────────┘
                       ↓
             Answer + Evidence
                       ↓
                 Practice / Quiz
```

### Snapdragon optimization path

The MVP keeps the retrieval and model layers modular. The intended next stage is to evaluate a compact model on the target Snapdragon-powered HP PC, then document the exact model, runtime, optimization path, latency, memory/resource usage, and answer quality.

Qualcomm AI Hub can be used as the optimization/deployment path when the selected model and target device are validated.

---

## 💻 Run Locally

### 1. Create an environment

```bash
python -m venv .venv
```

### 2. Activate it

**Windows:**
```bash
.venv\\Scripts\\activate
```

**macOS/Linux:**
```bash
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Launch

```bash
streamlit run app.py
```

Then open the local Streamlit URL shown in the terminal.

---

## 🤖 Optional Local LLM

The app can optionally call a local Ollama server. The default model name is configurable through:

```bash
OLLAMA_MODEL=qwen3:4b
```

If the local LLM is unavailable, the MVP automatically falls back to its evidence-based extractive answer path.

This design avoids making the core demo dependent on a cloud API.

---

## 📊 Evaluation Plan

For the competition, the strongest evidence should come from **real measurements**, not estimated claims.

Measure on the target Snapdragon-powered HP PC:

1. p50/p95 retrieval and response latency
2. Peak memory/resource usage
3. Groundedness against supplied study material
4. Quiz usefulness / learner accuracy
5. Offline continuity
6. Model size and optimization details

See [`docs/EVALUATION_PLAN.md`](docs/EVALUATION_PLAN.md).

---

## 🏆 Competition Positioning

**One-line pitch:**

> *A private study copilot that brings useful AI to the edge—grounded in the learner's own material and engineered for the AI PC.*

**Differentiator:** not just “AI that answers questions,” but a **personal learning loop** that connects explanation, evidence, practice, revision, and re-testing.

---

## 🗺️ Roadmap

### Phase 1 — MVP ✅
Local PDF ingestion, retrieval, evidence, answers, practice questions.

### Phase 2 — Snapdragon optimization 🔄
Select a compact model, optimize for the target Snapdragon device, measure latency/resource use, and document the exact deployment path.

### Phase 3 — Adaptive learning 🔄
Track concept-level mistakes, generate targeted revision, and schedule re-tests.

### Phase 4 — Product polish 🔄
Offline-first UX, accessibility, multilingual explanations, richer coding practice, and visual learning aids.

---

## 👩‍💻 Author

**Anuradha**

Built as an individual project for the Snapdragon AI Lab Build & Present Challenge.

---

## ⚠️ Responsible Submission Note

This repository intentionally separates **implemented functionality** from **planned Snapdragon optimization**. Any competition submission should replace placeholders with actual screenshots, device details, model/runtime information, and measured benchmarks before claiming them as results.
