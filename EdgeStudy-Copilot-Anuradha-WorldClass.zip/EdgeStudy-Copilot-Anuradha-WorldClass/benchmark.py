"""Small retrieval-only benchmark.

This measures the retrieval layer on the current machine. It is NOT a Snapdragon
hardware benchmark and must not be presented as one.
"""

import time
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

chunks = [
    "Edge AI processes inference locally on the device and can reduce network dependency.",
    "Retrieval augmented generation finds relevant evidence before generating an answer.",
    "Quantization can reduce model size and improve deployment efficiency on edge hardware.",
    "A good evaluation should measure latency, memory use, accuracy and groundedness.",
] * 100

vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
matrix = vectorizer.fit_transform(chunks)

queries = [
    "What is edge AI?",
    "Why use retrieval?",
    "What does quantization do?",
]

times_ms = []
for query in queries:
    start = time.perf_counter()
    cosine_similarity(vectorizer.transform([query]), matrix)
    times_ms.append((time.perf_counter() - start) * 1000)

print("Retrieval latency (ms):", [round(x, 2) for x in times_ms])
print("Mean retrieval latency (ms):", round(sum(times_ms) / len(times_ms), 2))
print("NOTE: This is a retrieval benchmark, not a Snapdragon hardware benchmark.")
