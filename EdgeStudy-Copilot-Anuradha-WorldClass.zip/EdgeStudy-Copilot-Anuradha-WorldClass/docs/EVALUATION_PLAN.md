# Evaluation Plan

A strong final submission should report measured results from the actual target Snapdragon-powered HP PC.

| Metric | How to measure | Evidence |
|---|---|---|
| Retrieval p50/p95 | Run repeated retrieval queries | Console log / table |
| End-to-end response latency | Repeat fixed prompts | Screen recording + table |
| Peak memory | OS/runtime measurement during inference | Screenshot + table |
| Groundedness | Human rubric against source passages | Evaluation set |
| Quiz usefulness | Learner correctness before/after practice | Small user study |
| Offline continuity | Disable network and repeat core flow | Demo recording |
| Model footprint | Record exact model + quantization | README / appendix |

### Suggested test set
Create 20–50 questions from the same study material. Label each as factual, conceptual, or multi-step. Record whether the answer is supported by the supplied evidence.

### Reporting rule
Only publish results that were actually measured. Clearly distinguish **prototype measurements** from **target-device Snapdragon measurements**.
