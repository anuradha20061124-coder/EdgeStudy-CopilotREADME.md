# 90-Second Demo Script — EdgeStudy Copilot

## 0–10 sec — Hook
“Imagine your study material stays with you, your AI understands it, and you can keep learning even when you don't want to send your notes to a cloud service. This is EdgeStudy Copilot.”

## 10–30 sec — Show the input
Upload a real study PDF. Show that the app indexes the material locally.

Say: “Instead of starting with the whole internet, EdgeStudy Copilot starts with the learner's own material.”

## 30–50 sec — Ask + evidence
Ask one question that is clearly answered by the PDF. Show the answer and expand **Evidence used**.

Say: “The response is grounded in retrieved passages from the learner's material, making the source of the answer visible.”

## 50–70 sec — Practice
Click **Generate 5 practice prompts** and show the questions.

Say: “The learning loop moves beyond answering: explain, practice, revise, and re-test.”

## 70–82 sec — Edge / Snapdragon value
“Designed for the AI PC, the architecture keeps the retrieval layer local and leaves the model layer modular. The next validation step is to optimize and benchmark a compact model on the target Snapdragon-powered HP PC.”

## 82–90 sec — Closing
“EdgeStudy Copilot is not just AI that answers. It is a private study copilot grounded in what the learner is actually studying. Built by Anuradha.”
