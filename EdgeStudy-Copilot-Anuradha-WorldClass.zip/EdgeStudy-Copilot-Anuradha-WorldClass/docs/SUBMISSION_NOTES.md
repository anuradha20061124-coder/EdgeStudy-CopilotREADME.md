# Competition Submission Notes

## Project
**EdgeStudy Copilot — Private, On-Device AI Learning Companion for Snapdragon-Powered HP PCs**

## Author
**Anuradha**

## What is implemented
- PDF ingestion
- Local text extraction
- Local TF-IDF retrieval
- Evidence display
- Extractive answer generation
- Optional local LLM path through Ollama
- Practice prompt generation
- Retrieval latency measurement

## What still requires real target-device validation
- Snapdragon-specific model optimization
- Qualcomm AI Hub integration details
- Hardware acceleration claims
- Snapdragon latency/memory benchmark numbers

## Submission integrity
Do not invent benchmark numbers, device specifications, model versions, optimization results, or screenshots. Replace planned items with measured evidence after testing on the target Snapdragon-powered HP PC.
